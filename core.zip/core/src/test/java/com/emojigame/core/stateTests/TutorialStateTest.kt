package com.emojigame.core.stateTests

import com.emojigame.core.entities.Emoji
import com.emojigame.core.states.*
import com.emojigame.core.ui.TutorialStateFlow
import com.emojigame.core.util.GameIntent
import io.mockk.*
import kotlinx.coroutines.flow.MutableStateFlow
import org.junit.Before
import org.junit.Test
import kotlin.test.assertEquals

class TutorialStateTest {

    private lateinit var gameStateManager: GameStateManager
    private lateinit var tutorialState: TutorialState

    @Before
    fun setup() {
        gameStateManager = mockk(relaxed = true)

        every { gameStateManager.tutorialFlow } returns MutableStateFlow(mockk(relaxed = true))
        every { gameStateManager.gameStateFlow } returns MutableStateFlow(mockk(relaxed = true))

        tutorialState = TutorialState(gameStateManager)
    }

    @Test
    fun `onExit should process ClearTutorial intent`() {
        tutorialState.onExit()

        verify { gameStateManager.processIntent(GameIntent.ClearTutorial) }
    }

}
