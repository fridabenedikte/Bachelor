package com.emojigame.core.entitiesTests

import com.emojigame.core.entities.Player
import com.emojigame.core.data.Platform
import com.emojigame.core.data.PlatformTags
import com.emojigame.core.util.Vector2f
import org.junit.Assert.*
import org.junit.Test
import kotlin.math.abs


class PlayerTest {

    @Test
    fun testApplyGravityUpdatesGravity() {
        val player = Player(Vector2f(0f, 500f), "Player")
        val gravity = Vector2f(0f, 9.8f)
        player.applyGravity(gravity)

        player.update(emptyList())
    }

    @Test
    fun testSetTargetSetsCorrectly() {
        val player = Player(Vector2f(0f, 500f), "Player")
        val target = Vector2f(100f, 500f)

        player.setTarget(target)

        assertEquals("Target should be set correctly", target, player.getTarget())
    }

    @Test
    fun testPlayerMovesTowardsTarget() {
        val player = Player(
            pos = Vector2f(0f, 500f),
            tag = "Player"
        )

        val target = Vector2f(100f, 500f)
        player.setTarget(target)

        val ground = Platform(
            id = "ground",
            pos = Vector2f(-1000f, 600f),
            width = 3000f,
            height = 400f,
            tag = PlatformTags.Ground,
            isEnabled = true
        )

        player.update(listOf(ground))

        val startX = player.pos.x

        var steps = 0
        val maxSteps = 100
        while (steps < maxSteps && player.movementState != Player.MovementState.IDLE) {
            player.update(listOf(ground))
            steps++
        }

        val endX = player.pos.x

        println("Final pos: $endX")

        assertTrue("Player should have moved towards the target (startX=$startX, endX=$endX)", endX > startX)
        assertTrue(
            "Player should have reached near the target (target.x=${target.x}, pos.x=$endX)",
            abs(target.x - endX) <= 2f
        )
    }

    @Test
    fun testUpdateStopsWhenBlocked() {
        val player = Player(Vector2f(0f, 500f), "Player")
        val target = Vector2f(100f, 500f)

        player.setTarget(target)

        val blockingPlatform = Platform(
            id = "block",
            pos = Vector2f(5f, 500f),
            width = 50f,
            height = 100f,
            tag = PlatformTags.Ground,
            isEnabled = true
        )

        repeat(10) { player.update(listOf(blockingPlatform)) }

        assertTrue("Player should not pass through the blocking platform", player.pos.x < 55f)
    }

    @Test
    fun testCloneCreatesIndependentCopy() {
        val player = Player(Vector2f(0f, 500f), "Player")
        val clone = player.clone()

        assertEquals("Cloned player should have same position", player.pos, clone.pos)
        assertEquals("Cloned player should have same tag", player.tag, clone.tag)
        assertNotSame("Clone should not be the same object", player, clone)
    }

}
