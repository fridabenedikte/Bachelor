# **Core Module**

This module contains shared logic that is independent of Android and Desktop. It includes **data models, game states, reusable logic, and utility functions** essential for cross-platform development.

---

## **Directory Structure**

```
core/
├── data/           # Data models for static information used across platforms
├── entities/       # Data models for moveable objects used across platforms
├── states/         # Game state management
├── ui/             # UI-related abstractions for cross-platform compatibility
├── util/           # Reusable helper functions and utilities
├── resources/      # Shared assets like JSON level data and emoji mappings
```

---

## **Directory Explanations and Example Code**
---

### **1. `data/` – Static Game Data**
This package holds **static data models** that are referenced across different parts of the game. These models typically represent **fixed data** that doesn’t change during gameplay.

#### **What to put here?**
- **Game metadata** (e.g., `GameConfig.kt`, `EmojiData.kt`)
- **Level structure definitions** that are read from JSON or other sources
- **Static lookup tables** (e.g., emoji mappings, theme definitions)

---

### **2. `entities/` – Core Game Entity Models**
This package contains **data classes** representing the core objects of the game. These classes should be **pure Kotlin** with no platform dependencies and should be serializable when necessary.

#### **What to put here?**
- Game objects (`Player`, `Emoji`, `Entity`)
- Serializable models for storage or transmission
- Dynamic entities that can interact with the game world

---

### **3. `states/` – Game State Management**
This directory manages different **game and UI states**, ensuring seamless transitions between different game phases.

#### **What to put here?**
- **Game session states** (`GameState.kt`, `PlayState.kt`)
- **State transition logic** (`GameStateManager.kt`)
- **UI-related game flow management** (handling UI state changes)

---

### **4. `ui/` – UI Abstractions for Cross-Platform Compatibility**
This package contains **interfaces and abstract classes** that ensure UI logic remains **platform-independent**.

#### **What to put here?**
- **Interfaces for UI components** that both Android and Desktop implementations will use
- **Abstract classes** for shared UI logic
- **Common drawing functions** (if any, to be implemented separately per platform)

---

### **5. `util/` – Utility Functions**
This package contains **helper functions** that provide essential functionality across the project.

#### **What to put here?**
- **Math utilities** (`Vector2f.kt`, `AABB.kt`)
- **Game logic helpers** (`EmojiManager.kt`, `InputHandler.kt`)
- **Logging and debugging tools** (`Logger.kt`)
- **Level loading utilities** (`LevelLoader.kt`)
- **Performance optimizations** (if applicable)

---

## **Guidelines for Core Module**
✔ **No platform-specific code.** Avoid Android, Desktop, or external libraries unless purely Kotlin.  
✔ **Keep logic reusable and maintainable.** Aim for modular, well-structured code.  
✔ **Ensure compatibility with both Android and Desktop.** The Core module should be the **foundation** of the game, ensuring **cross-platform compatibility** and a **clean, maintainable architecture**.

---

### **Final Thoughts**
This module serves as the **backbone** of the game, providing the **game logic, data handling, and shared utilities** that all platforms rely on. Keeping it **pure Kotlin** ensures flexibility and **long-term maintainability**.
